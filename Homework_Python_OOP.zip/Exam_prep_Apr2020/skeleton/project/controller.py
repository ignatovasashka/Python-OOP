from project.card.card_repository import CardRepository
from project.card.magic_card import MagicCard
from project.card.trap_card import TrapCard
from project.player.beginner import Beginner
from project.player.advanced import Advanced
from project.player.player_repository import PlayerRepository


class Controller():
    def __init__(self):
        self.player_repository = PlayerRepository()
        self.card_repository = CardRepository()

    def add_player(self, type, username):
        if type == "Beginner":
            self.player_repository.players.append(Beginner(username))
            return f"Successfully added player of type {type} with username: {username}"
        elif type == "Advanced":
            self.player_repository.players.append(Advanced(username))
            return f"Successfully added player of type {type} with username: {username}"

    def add_card(self, type, name):
        if type == "Magic":
            self.card_repository.cards.append(MagicCard(name))
            return  f"Successfully added card of type {type}Card with name: {name}"
        elif type == "Trap":
            self.card_repository.cards.append(TrapCard(name))
            return f"Successfully added card of type {type}Card with name: {name}"

    def add_player_card(self, username, card_name):
        for pl in self.player_repository.players:
            for c in self.card_repository.cards:
                if pl.username == username and c.name == card_name:
                    pl.card_repository.cards.append(c)

    def fight(self, attack_name, enemy_name):
        # todo - battle?
        attacker_health_left = 0
        enemy_health_left = 0

        return f"Attack user health {attacker_health_left} - Enemy user health {enemy_health_left}"

    def report(self):
        result = ""
        for pl in self.player_repository.players:
            result += f"Username: {pl.username} - Health: {pl.health} - Cards {pl.cards_repository.cards.count()}/n"
            for c in pl.card_repository.cards:
                result += f"### Card: {c.name} - Damage: {c.card_damage}"

        return result