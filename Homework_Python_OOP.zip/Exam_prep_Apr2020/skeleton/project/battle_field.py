class BattleField():
    def fight(self, attacker, enemy):
        if attacker.is_dead or enemy.is_dead:
            raise ValueError("Player is dead!")
        if attacker.__class__.__name__ == "Beginner":
            attacker.health += 40
            for c in attacker.card_repository.cards:
                c.damage_points += 30
        bonus_health_points_attacker = sum([hp for hp in attacker.card_repository.cards.health_points])
        bonus_health_points_enemy = sum([hp for hp in enemy.card_repository.cards.health_points])
        attacker.health += bonus_health_points_attacker
        enemy.health += bonus_health_points_enemy

        attacker.health -=