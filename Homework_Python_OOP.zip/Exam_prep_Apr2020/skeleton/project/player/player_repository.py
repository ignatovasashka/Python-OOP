class PlayerRepository():
    def __init__(self):
        self.count = 0
        self.players = []

    def add(self, player):
        for pl in self.players:
            if pl.username == player.username:
                raise ValueError(f"Player {pl.username} already exists!")
            self.players.append(player)
            self.count += 1

    def remove(self, player):
        if player == "":
            raise ValueError("Player cannot be an empty string!")
        for pl in self.players:
            if pl.username == player:
                self.players.remove(pl)
                self.count -= 1

    def find(self, username):
        for pl in self.players:
            if pl.username == username:
                return pl
